## Version4 PRO Prank Script
##
## This PowerShell script orchestrates a multi‑stage prank sequence.  It
## compiles all of the working tricks you’ve tried previously and adds a
## few more safe effects.  The sequence includes opening multiple CMD
## windows, changing the desktop wallpaper, playing a sound, opening
## YouTube links, shaking existing windows, launching and moving helper
## applications, hiding and restoring desktop icons, displaying
## message boxes, temporarily hiding the mouse cursor, playing built‑in
## system sounds, auto‑typing into Notepad, hiding and restoring the
## taskbar, resizing windows, and finally creating and displaying a
## HACKED.txt message.  The script runs quietly from its folder so
## everything stays self‑contained.

## Always run from the directory this script lives in
Set-Location -Path $PSScriptRoot

## --- Helper classes for interacting with the Windows API ---
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Collections.Generic;

public class W32 {
  public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lp);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
  [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr hWnd,int X,int Y,int W,int H,bool repaint);
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder s, int nMaxCount);
  [DllImport("user32.dll")] public static extern IntPtr FindWindow(string cls, string title);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern short ShowCursor(bool bShow);
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
  public static List<IntPtr> TopWindows() {
    var list = new List<IntPtr>();
    EnumWindows((h,l) => { list.Add(h); return true; }, IntPtr.Zero);
    return list;
  }
}
"@

function Get-Title([IntPtr]$h) {
  $sb = New-Object System.Text.StringBuilder 512
  [void][W32]::GetWindowText($h,$sb,$sb.Capacity)
  return $sb.ToString()
}

## --- 1) CMD spam: open and close multiple console windows ---
for ($i=1; $i -le 20; $i++) {
  Start-Process "cmd.exe" -ArgumentList "/c timeout /t 1 >nul"
  Start-Sleep -Milliseconds 150
}

## --- 2) Change desktop wallpaper ---
$imgPath = Join-Path $PSScriptRoot 'image9.png'
Add-Type -TypeDefinition @"
using System.Runtime.InteropServices;
public class Native {
  [DllImport("user32.dll", SetLastError=true)]
  public static extern bool SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@
[Native]::SystemParametersInfo(20,0,$imgPath,3) | Out-Null

## --- 3) Play embedded sound file ---
$soundPath = Join-Path $PSScriptRoot 'mmoo.mp3'
Add-Type -AssemblyName presentationCore
$player = New-Object System.Windows.Media.MediaPlayer
$player.Open($soundPath)
$player.Volume = 1.0
$player.Play()

## --- 4) Open YouTube tabs in the default browser ---
$urls = @(
  'https://youtu.be/j9WhUwyanD8?si=onP5edkygC3W0WGv',
  'https://youtu.be/FgEQyWMFruI?si=A5EinKnV7XkB-WSG'
)
foreach ($u in $urls) { Start-Process $u; Start-Sleep -Milliseconds 700 }

## --- 5) Shake all visible, non‑minimized windows ---
$wins = [W32]::TopWindows()
foreach ($h in $wins) {
  if ([W32]::IsWindowVisible($h) -and -not [W32]::IsIconic($h)) {
    $rect = New-Object W32+RECT
    if ([W32]::GetWindowRect($h,[ref]$rect)) {
      $w = $rect.Right - $rect.Left
      $hgt = $rect.Bottom - $rect.Top
      $x = $rect.Left
      $y = $rect.Top
      for ($j=0; $j -lt 12; $j++) {
        [W32]::MoveWindow($h,$x+15,$y+10,$w,$hgt,$true) | Out-Null
        Start-Sleep -Milliseconds 25
        [W32]::MoveWindow($h,$x-15,$y-10,$w,$hgt,$true) | Out-Null
        Start-Sleep -Milliseconds 25
      }
    }
  }
}

## --- 6) Launch helper apps (Notepad, Calculator, Paint) and move them ---
$apps = @('notepad.exe','calc.exe','mspaint.exe')
$procs = @()
foreach ($app in $apps) {
  try {
    $proc = Start-Process $app -PassThru
    $procs += $proc
    Start-Sleep -Milliseconds 500
  } catch {}
}

foreach ($proc in $procs) {
  try {
    for ($try = 0; $try -lt 16; $try++) {
      $windows = [W32]::TopWindows()
      foreach ($h in $windows) {
        if ([W32]::IsWindowVisible($h) -and -not [W32]::IsIconic($h)) {
          $title = Get-Title $h
          if ($title -like "*Notepad*" -or $title -like "*Calculator*" -or $title -like "*Paint*") {
            $rect = New-Object W32+RECT
            if ([W32]::GetWindowRect($h,[ref]$rect)) {
              $w = $rect.Right - $rect.Left
              $hgt = $rect.Bottom - $rect.Top
              $x = $rect.Left
              $y = $rect.Top
              [W32]::MoveWindow($h,$x+25,$y-12,$w,$hgt,$true) | Out-Null
              Start-Sleep -Milliseconds 18
              [W32]::MoveWindow($h,$x-25,$y+12,$w,$hgt,$true) | Out-Null
              Start-Sleep -Milliseconds 18
            }
          }
        }
      }
      Start-Sleep -Milliseconds 120
    }
  } catch {}
}

## --- 7) Hide desktop icons then restore them ---
$adv = 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced'
try { $orig = (Get-ItemProperty -Path $adv -Name HideIcons -ErrorAction SilentlyContinue).HideIcons } catch { $orig = 0 }
Set-ItemProperty -Path $adv -Name HideIcons -Value 1 -Type DWord
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Process explorer.exe
Start-Sleep -Seconds 2
Set-ItemProperty -Path $adv -Name HideIcons -Value $orig -Type DWord
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Process explorer.exe

## --- 8) Display prank message boxes ---
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show('Warning: Suspicious activity detected!','System Alert','OK','Warning') | Out-Null
Start-Sleep -Milliseconds 600
[System.Windows.Forms.MessageBox]::Show('Just kidding :)','Relax','OK','Information') | Out-Null

## --- 9) Additional fun effects ---

### 9.1 Hide the mouse cursor temporarily
for ($i=0; $i -lt 3; $i++) { [void][W32]::ShowCursor($false) }
Start-Sleep -Seconds 4
for ($i=0; $i -lt 3; $i++) { [void][W32]::ShowCursor($true) }

### 9.2 Play system sounds in succession
1..5 | ForEach-Object {
  [System.Media.SystemSounds]::Exclamation.Play(); Start-Sleep -Milliseconds 500
  [System.Media.SystemSounds]::Hand.Play(); Start-Sleep -Milliseconds 400
}

### 9.3 Auto‑type into Notepad
$np = Start-Process notepad -PassThru
Start-Sleep -Seconds 1
Add-Type -AssemblyName Microsoft.VisualBasic
[Microsoft.VisualBasic.Interaction]::AppActivate($np.Id) | Out-Null
Start-Sleep -Milliseconds 300
$phrase = 'YOU HAVE BEEN HACKED!  Just kidding :) '
for ($i=0; $i -lt 3; $i++) {
  [System.Windows.Forms.SendKeys]::SendWait($phrase)
  Start-Sleep -Milliseconds 200
}

### 9.4 Hide the taskbar briefly then restore
$tray = [W32]::FindWindow('Shell_TrayWnd',$null)
if ($tray -ne [IntPtr]::Zero) {
  [void][W32]::ShowWindow($tray,0)  # hide
  Start-Sleep -Seconds 2
  [void][W32]::ShowWindow($tray,5)  # show
}

### 9.5 Resize all visible windows slightly smaller
$wins2 = [W32]::TopWindows()
foreach ($h in $wins2) {
  if ([W32]::IsWindowVisible($h) -and -not [W32]::IsIconic($h)) {
    $rect = New-Object W32+RECT
    if ([W32]::GetWindowRect($h,[ref]$rect)) {
      $w = $rect.Right - $rect.Left
      $hgt = $rect.Bottom - $rect.Top
      $x = $rect.Left
      $y = $rect.Top
      $newW = [Math]::Max(220, $w - 60)
      $newH = [Math]::Max(160, $hgt - 40)
      [W32]::MoveWindow($h,$x,$y,$newW,$newH,$true) | Out-Null
    }
  }
}

### 9.6 Close helper apps created earlier and the auto‑typing Notepad
foreach ($p in $procs) { try { $p.CloseMainWindow() | Out-Null } catch {} }
try { $np.CloseMainWindow() | Out-Null } catch {}

## --- 10) Create and display the HACKED.txt message ---
$txtPath = Join-Path $PSScriptRoot 'HACKED.txt'
'YOU HAVE BEEN HACKED!' | Out-File -FilePath $txtPath -Encoding ASCII
Start-Process notepad.exe $txtPath

## Give everything time to finish and let the target stew
Start-Sleep -Seconds 20
